package com.example.intent2

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    lateinit var bt: Button
    lateinit var btAjouter:Button
    lateinit var monTexte:TextView


    private lateinit var recyclerView: RecyclerView
    private lateinit var manager: RecyclerView.LayoutManager
    private lateinit var myAdapter: RecyclerView.Adapter<*>

    var values= arrayListOf<String>("item1", "item2" , "item3", "item4", "item5")
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        bt = findViewById(R.id.btnSuivant)
        btAjouter=findViewById(R.id.btAjouter)
        monTexte=findViewById(R.id.txtMonTexte)

        bt.setOnClickListener{
            var s = monTexte.text.toString()
            var i = Intent(this,Activity2::class.java)
            i.putExtra("cle",s)
            startActivity(i)
        }
        manager = LinearLayoutManager(this)
        myAdapter = MyAdapter(values)
        recyclerView = findViewById<RecyclerView>(R.id.recyclerView).apply {
            layoutManager = manager
            adapter = myAdapter
        }



    }




}