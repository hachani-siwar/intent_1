package com.example.intent2

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class MyAdapter(private val myDataset: ArrayList<String>):
     RecyclerView.Adapter<MyAdapter.ViewHolder>(){
         override fun onCreateViewHolder(parent:ViewGroup,viewType : Int):ViewHolder {
             val vh = LayoutInflater.from(parent.context).inflate(R.layout.ligne,parent,false)
             return ViewHolder(vh)
         }
    override fun onBindViewHolder(holder:ViewHolder,position:Int){
        val ItemsViewModel = myDataset[position]
        holder.vText.text = ItemsViewModel.text
     }

    override fun getItemCount():Int{
        return myDataset.size
    }


    class ViewHolder(val itemView: View):RecyclerView.ViewHolder(itemView)
    {
        val vText = itemView.findViewById(R.id.textView) as TextView
    }
}