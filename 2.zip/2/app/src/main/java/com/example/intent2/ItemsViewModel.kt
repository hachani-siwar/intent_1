package com.example.intent2

class ItemsViewModel  (val image:Int, val text:String){
}