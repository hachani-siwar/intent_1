package comp.devmob.act1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log

class MainActivity : AppCompatActivity() {
    private val LOG_TAG = MainActivity::class.simpleName
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
    fun LaunchSecondActivity(view: view ?){
        Log.d(LOG_TAG, "Button Clicked!")
        var intent = Intent(this,Activity2::class.java)
        resultLauncher.launch(intent)
    }
}